<?php 
$b = "Foo";
$a ="Bar";
echo "$a Foo";


?>
