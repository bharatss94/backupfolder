<html>

<head>
<title>DIC ChatBox Beta 1</title>
</head>

<body>

<h1></DIC> Chat Box</h1>
<form id="signInForm">
	<input id="userName" type="text">
	<input id="signInButt" name="signIn" type="submit" value="Sign in">
	<span id="signInName">User name</span>
</form>

<div id="chatBox"></div>

<div id="usersOnLine"></div>

<form id="messageForm">
	<input id="message" type="text">
	<input id="send" type="submit" value="Send">
<div id="serverRes"></div>
</form>
</body>
</html>

