<?php
/*
 if ($_SERVER["REQUEST_METHOD"]=="POST") {
    $port = $_POST['port'];

    echo $port;
  }
*/
$port=array(5260,5261);

echo $port[1];
?>
