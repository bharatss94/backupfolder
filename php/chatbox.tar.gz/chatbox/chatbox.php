<!DOCTYPE html>

<head>
<title>ChatBox</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<form name="frmChat" id="frmChat">
 <input type="text" name="chat-user" id="chat-user" placeholder="People who are online" class="chat-input" required />


  <div id="chat-box"></div>
      <input type="text" name="chat-user" id="chat-user" placeholder="Name" class="chat-input" required />
      <input type="text" name="chat-message" id="chat-message" placeholder="Message"  class="chat-input chat-message" required />
                        <input type="submit" id="btnSend" name="send-chat-message" value="Send" >
</form>
</body>


</body>
</html>
