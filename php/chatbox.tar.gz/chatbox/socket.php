<!DOCTYPE HTML>
<head>
</head>
<body>
<form action="server.php" method="post">
  port value: <input name="port" type="text" />
 
  <input name="submit" type="submit" />
</form>
</body>
