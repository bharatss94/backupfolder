$(function() {    

getMessages = function() {       
 var feedback = $.ajax({
        type: "POST",
        url: "index.php?action=online",
        async: false
    }).success(function(){
        setTimeout(function(){get_fb();}, 1000);
    }).responseText;

    $('#links').html(feedback);
    }   
 getMessages();
})
