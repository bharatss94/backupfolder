#include<stdio.h>
void main()
{



int i=10;
int j=11;
int k=12;
printf("%d,%d,%d", i,++j,k++);
}
