<?php
 if (isset($_SESSION['member_name']) && $_SESSION['member_name'] && $_SESSION['member_pass']) {
// get profiles lists
//setInterval ( "myFunction()", 1000 );                 
//function myFunction(){
//$name=$_SESSION['member_name'];
//echo "<script> console.log($name)</script>";
$sProfiles = $GLOBALS['CProfiles']->getProfilesBlock();
$sOnlineMembers = $GLOBALS['CProfiles']->getProfilesBlock(10, true);
}
?>
