<?php
echo strtr(file_get_contents('templates/main_page.html'), $aKeys);
?>
